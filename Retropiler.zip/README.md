Transpiler
==========
A retrofitting customizable transpiler for kOS.

This project is free to use and distribute under the terms of the `Lesser Genneral Public License Version 3` as published by the `Free Software Foundation`.
Check [LICENSE.txt](LICENSE.txt) for more information.
